

let imgarray=["../im1.jpg","../im2.jpg","../im3.jpg"];
function imgSelect(){
    let imgCurr=imgarray[Math.floor(Math.random()*imgarray.length)];
    document.querySelector(".im").src=imgCurr;
}
setInterval(imgSelect,2000);